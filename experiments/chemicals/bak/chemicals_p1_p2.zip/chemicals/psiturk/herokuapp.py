import psiturk.experiment_server as exp
exp.launch()
