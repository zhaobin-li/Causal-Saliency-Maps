const simulate = false;
// const debugMode = false;
// or set using:
const debugMode = mode === "debug"; // psiturk/templates/default.html:29

const psiTurk = new PsiTurk(uniqueId, adServerLoc, mode);

const numDemo = 20;
const numDemoRange = [...Array(numDemo).keys()];

const numTrials = debugMode ? 10 : 30;
const numTrialsRange = [...Array(numTrials).keys()].map((x) => x + numDemo);

const robotConditions = ["same", "opp", "random"];
robotCondition = robotConditions[condition];

const getSecondRobotLabel = (saliencyLabel) => {
  switch (robotCondition) {
    case "same":
      return saliencyLabel;
    case "opp":
      return saliencyLabel === "safe" ? "toxic" : "safe";
    case "random":
      return sampleOne(["safe", "toxic"]);
  }
};

const salPrompt = `The brightly-colored salient molecules are important to the robot's decision. The robot thinks the non-salient molecules don't match its predicted label or don't know which label to assign to those molecules`;

let labelPrompt;

switch (robotCondition) {
  case "same":
  case "opp":
    labelPrompt = `The two robots, ${getInlineIcon(
      "robot1"
    )} and ${getInlineIcon("robot2")}, always give ${
      robotCondition === "same" ? "the same" : "opposite"
    } labels`;
    break;
  case "random":
    labelPrompt = `The two robots, ${getInlineIcon(
      "robot1"
    )} and ${getInlineIcon(
      "robot2"
    )} always give labels independently of one another`;
    break;
}

const algoPrompt = `The two robots don't use the same rules to come to their decisions, and may or may not give the same saliency maps`;

const jsPsych = initJsPsych({
  show_progress_bar: true,
  auto_update_progress_bar: false,

  on_trial_finish: function (data) {
    if (debugMode) {
      console.log(jsPsych.data.get().json(true));
    }
  },

  on_finish: function (data) {
    psiTurk.recordTrialData(data);
    psiTurk.saveData({
      success: () => psiTurk.completeHIT(),
    });

    if (debugMode) {
      jsPsych.data.get().localSave("csv", "debug.csv");
    }
  },
});

jsPsych.data.addProperties({
  condition: condition,
  robotCondition: robotCondition,
});

const timeline = [];

if (debugMode)
  timeline.push({
    type: jsPsychHtmlKeyboardResponse,
    stimulus: `<p class="important"><strong>Debugging: </strong>Press any key to start experiment.</p><p>Condition: ${condition} <br> robotCondition: ${robotCondition}. </p>`,
  });

const minScreenResolution = {
  type: jsPsychBrowserCheck,
  minimum_width: 800,
  minimum_height: 600,
};

const browserCheck = {
  type: jsPsychBrowserCheck,
  inclusion_function: (data) => {
    return ["chrome"].includes(data.browser);
  },
  exclusion_message: () =>
    `<p>You must use Chrome to complete this experiment.</p>`,
};

timeline.push(minScreenResolution);
timeline.push(browserCheck);

let images = [];

numDemoRange.forEach(
  (i) =>
    (images = images.concat(
      ["mol", "sal", "opp", "same"].map((molImg) => getMolPath(molImg, i))
    ))
);

// main trials don't require molecules image
numTrialsRange.forEach(
  (i) =>
    (images = images.concat(
      ["sal", "opp", "same"].map((molImg) => getMolPath(molImg, i))
    ))
);

images.push("/static/stimuli/colorbar.svg");

const preload = {
  type: jsPsychPreload,
  auto_preload: true,
  images: images,
};

timeline.push(preload);

const gender = {
  type: jsPsychSurveyMultiChoice,
  questions: [
    {
      prompt: "What is your gender? (optional)",
      options: ["Male", "Female", "Other"],
      required: false,
      name: "gender",
    },
  ],
};

const age = {
  type: jsPsychSurveyText,
  questions: [
    {
      prompt: "What is your age? (optional)",
      required: false,
      name: "age",
    },
  ],
};

timeline.push(gender);
timeline.push(age);

const instructions = {
  type: jsPsychInstructions,
  pages: [
    `<p>Glorbian aliens are exploring newly discovered chemicals in a parallel universe and are testing 2 robots, ${getInlineIcon(
      "robot1"
    )} and ${getInlineIcon(
      "robot2"
    )}, to label these chemicals as ${getInlineIcon("safe")} or ${getInlineIcon(
      "toxic"
    )}. </p>`,

    `<p>These are the 2 robots: </p><div class="grid-col">${getBlockIcon(
      "robot1",
      "fa-shake"
    )}${getBlockIcon("robot2", "fa-shake")}</div>`,

    `<p>These are the 2 chemical labels: </p><div class="grid-col">${getBlockIcon(
      "safe",
      "fa-fade"
    )}${getBlockIcon("toxic", "fa-fade")}</div>`,

    `<p>The chemicals are passed as images to the robots.</p>
    <div class="grid-col">
    <img src=${getMolPath("mol", numDemoRange.shift())}>
    <img src=${getMolPath("mol", numDemoRange.shift())}>
    </div>`,

    `<p>The robots will label these images as ${getInlineIcon(
      "safe"
    )} or ${getInlineIcon("toxic")}. For instance, ${getInlineIcon(
      "robot1"
    )} labels the left image as ${getInlineIcon("toxic")} while ${getInlineIcon(
      "robot2"
    )} labels the right image as ${getInlineIcon("safe")}.</p>

    <div class="grid-col"><div class="robot-label-img">${getRobotwLabel(
      "robot1",
      "toxic"
    )}<img src=${getMolPath("mol", numDemoRange.shift())}></div>
    <div class="robot-label-img">${getRobotwLabel(
      "robot2",
      "safe"
    )}<img src=${getMolPath("mol", numDemoRange.shift())}></div>
    </div>`,

    `<p>Given an image, the robot may also give us a "saliency map", which tells us where it is looking at to make its decision.</p> <p class="important"><strong>Important:</strong> ${salPrompt}. </p><img src="/static/stimuli/colorbar.svg" class="colorbar">
     <div class="grid-col">
     <div class="robot-label-img">${getRobotwLabel(
       "robot1",
       "safe"
     )}<img src=${getMolPath("sal", numDemoRange.shift())}></div>
     <div class="robot-label-img">${getRobotwLabel(
       "robot2",
       "toxic"
     )}<img src=${getMolPath("sal", numDemoRange.shift())}></div>
     </div>`,

    `<p>Now your aim is to cover up some molecules to manipulate a robot's label. Given two images with some molecules made invisible, select the one which will result in the given label. Let's practice!</p>`,
  ],
  show_clickable_nav: true,
  on_finish: () => jsPsych.setProgressBar(0.1),
};

timeline.push(instructions);

const mainFactory = (timelineVariables, isPractice = true) => {
  return {
    timeline: [
      {
        type: jsPsychHtmlButtonResponse,
        stimulus: () => {
          let originalStr;
          if (
            jsPsych.timelineVariable("saliencyRobot") ===
            jsPsych.timelineVariable("promptRobot")
          ) {
            originalStr = `${getInlineIcon(
              jsPsych.timelineVariable("saliencyRobot")
            )} thinks the image is ${getInlineIcon(
              jsPsych.timelineVariable("saliencyLabel")
            )} and tells us where it is looking at.`;
          } else {
            if (robotCondition === "same") {
              originalStr = `Both ${getInlineIcon(
                jsPsych.timelineVariable("saliencyRobot")
              )} and ${getInlineIcon(
                jsPsych.timelineVariable("promptRobot")
              )} think the image is ${getInlineIcon(
                jsPsych.timelineVariable("saliencyLabel")
              )}.`;
            } else {
              originalStr = `${getInlineIcon(
                jsPsych.timelineVariable("saliencyRobot")
              )} thinks the image is ${getInlineIcon(
                jsPsych.timelineVariable("saliencyLabel")
              )} and ${getInlineIcon(
                jsPsych.timelineVariable("promptRobot")
              )} thinks the image is ${getInlineIcon(
                getSecondRobotLabel(jsPsych.timelineVariable("saliencyLabel"))
              )}.`;
            }
            originalStr += `<br> Only ${getInlineIcon(
              jsPsych.timelineVariable("saliencyRobot")
            )} tells us where it is looking at.`;
          }
          return `<p>${originalStr}</p><div class="robot-label-img">${getRobotwLabel(
            jsPsych.timelineVariable("saliencyRobot"),
            jsPsych.timelineVariable("saliencyLabel")
          )}<img src=${jsPsych.timelineVariable(
            "sal"
          )} ></div><div class="prompt">${getRobotwLabel(
            jsPsych.timelineVariable("promptRobot"),
            jsPsych.timelineVariable("promptLabel")
          )}</div>`;
        },
        prompt: () =>
          `<p>Covering up which molecules will cause ${getInlineIcon(
            jsPsych.timelineVariable("promptRobot")
          )} to label the occluded image as ${getInlineIcon(
            jsPsych.timelineVariable("promptLabel")
          )}?</p>`,
        choices: jsPsych.timelineVariable("buttonPaths"),
        button_html: `<img src=%choice%>`,
        data: {
          trial: isPractice ? "practice" : "results",
        },
        on_finish: (data) => {
          Object.assign(data, jsPsych.getAllTimelineVariables());

          data.responseCompare = data.buttonOrder[data.response];
          data.robotCompare =
            data.saliencyRobot === data.promptRobot
              ? "sameRobot"
              : robotCondition + "Label";
          data.labelCompare =
            data.saliencyLabel === data.promptLabel ? "same" : "opp";

          if (!isPractice) {
            jsPsych.setProgressBar(
              jsPsych.getProgressBarCompleted() + (1 / numTrials) * 0.7 // 1 - instructions - practice
            );
          }
        },
      },
    ],
    timeline_variables: timelineVariables,
    randomize_order: !isPractice,
  };
};

const timelineFactory = (
  saliencyRobot,
  saliencyLabel,
  promptRobot,
  promptLabel,
  imgNum,
  buttonOrder
) => {
  return {
    saliencyRobot,
    saliencyLabel,
    promptRobot,
    promptLabel,

    imgNum,
    buttonOrder,

    get sal() {
      return getMolPath("sal", this.imgNum);
    },

    get buttonPaths() {
      return this.buttonOrder.map((molImg) => getMolPath(molImg, this.imgNum));
    },
  };
};

const practice = {
  timeline: [
    mainFactory([
      timelineFactory(
        "robot1",
        "safe",
        "robot1",
        "safe",
        numDemoRange.shift(),
        ["opp", "same"]
      ),
      timelineFactory(
        "robot2",
        "toxic",
        "robot2",
        "toxic",
        numDemoRange.shift(),
        ["same", "opp"]
      ),
      timelineFactory(
        "robot1",
        "safe",
        "robot1",
        "toxic",
        numDemoRange.shift(),
        ["opp", "same"]
      ),
      timelineFactory(
        "robot2",
        "toxic",
        "robot2",
        "safe",
        numDemoRange.shift(),
        ["same", "opp"]
      ),
    ]),

    {
      type: jsPsychInstructions,
      pages: [
        `<p>Now things has got a tad harder &mdash; one robot will give you its saliency map and decision, but you have to manipulate another robot! For the 2nd robot in the prompt, we only get its label but not its saliency map. </p>`,

        `<p>But there are some things which could help! ${labelPrompt}. Below are some examples: </p>
        <div class="grid-col">${getRobotwLabel(
          "robot1",
          "safe"
        )}<img src=${getMolPath("mol", numDemoRange.shift())}>${getRobotwLabel(
          "robot2",
          robotCondition === "random" ? "toxic" : getSecondRobotLabel("safe")
        )}</div>
        <div class="grid-col">${getRobotwLabel(
          "robot1",
          "toxic"
        )}<img src=${getMolPath("mol", numDemoRange.shift())}>${getRobotwLabel(
          "robot2",
          robotCondition === "random" ? "toxic" : getSecondRobotLabel("toxic")
        )}</div>`,

        `<div class="grid-col">${getRobotwLabel(
          "robot2",
          "safe"
        )}<img src=${getMolPath("mol", numDemoRange.shift())}>${getRobotwLabel(
          "robot1",
          robotCondition === "random" ? "safe" : getSecondRobotLabel("safe")
        )}</div>
        <div class="grid-col">${getRobotwLabel(
          "robot2",
          "toxic"
        )}<img src=${getMolPath("mol", numDemoRange.shift())}>${getRobotwLabel(
          "robot1",
          robotCondition === "random" ? "safe" : getSecondRobotLabel("toxic")
        )}</div>`,

        `<p class="important"><strong>Important:</strong> ${algoPrompt}. Let's practice!</p>`,
      ],
      show_clickable_nav: true,
    },
    mainFactory([
      timelineFactory(
        "robot2",
        "safe",
        "robot1",
        "safe",
        numDemoRange.shift(),
        ["opp", "same"]
      ),
      timelineFactory(
        "robot1",
        "toxic",
        "robot2",
        "toxic",
        numDemoRange.shift(),
        ["opp", "same"]
      ),
      timelineFactory(
        "robot2",
        "toxic",
        "robot1",
        "safe",
        numDemoRange.shift(),
        ["same", "opp"]
      ),
      timelineFactory(
        "robot1",
        "safe",
        "robot2",
        "toxic",
        numDemoRange.shift(),
        ["same", "opp"]
      ),
    ]),
    {
      type: jsPsychInstructions,
      pages: [
        `<p class="important"><strong>Reminder:</strong> ${salPrompt}. </p>
        <p class="important"><strong>Reminder:</strong> ${labelPrompt}. ${algoPrompt}.</p>
        <p>Let's begin! </p>`,
      ],
      show_clickable_nav: true,
    },
  ],
  on_timeline_finish: () => jsPsych.setProgressBar(0.2),
};
timeline.push(practice);

const mainTimelineVariables = [];

numTrialsRange.forEach((numImg) =>
  mainTimelineVariables.push(
    timelineFactory(
      sampleOne(["robot1", "robot2"]),
      sampleOne(["safe", "toxic"]),
      sampleOne(["robot1", "robot2"]),
      sampleOne(["safe", "toxic"]),
      numImg,
      jsPsych.randomization.shuffle(["same", "opp"])
    )
  )
);

timeline.push(mainFactory(mainTimelineVariables, false));

const feedback = {
  type: jsPsychSurveyText,
  questions: [
    {
      prompt: "Any feedback? (optional)",
      required: false,
      name: "feedback",
    },
  ],
};

timeline.push(feedback);

if (debugMode) {
  timeline.push({
    type: jsPsychHtmlKeyboardResponse,
    stimulus: function () {
      const mainTrials = jsPsych.data.get().filter({ trial: "results" });

      console.assert(mainTrials.count() === numTrials);

      return `<p class="important"><strong>Debugging: </strong>Press any key to complete experiment. Thank you!</p>
        
      <p>Average RT: ${Math.round(mainTrials.select("rt").mean())}ms</p>`;
    },
  });
}

if (simulate) {
  jsPsych.simulate(timeline, "data-only");
} else {
  jsPsych.run(timeline);
}
