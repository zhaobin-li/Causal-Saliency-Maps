const getIconName = (iconType) => {
  switch (iconType) {
    case "robot1":
      return "Aike";
    case "robot2":
      return "Zubo";
    case "safe":
      return "safe";
    case "toxic":
      return "toxic";
    default:
      console.log("Invalid iconType");
  }
};

const getIcon = (iconType, classNames = "") => {
  let iconClasses;
  switch (iconType) {
    case "robot1":
      iconClasses = `fa-solid fa-robot`;
      break;
    case "robot2":
      iconClasses = `fa-brands fa-android`;
      break;
    case "safe":
      iconClasses = `fa-solid fa-seedling`;
      break;
    case "toxic":
      iconClasses = `fa-solid fa-biohazard`;
      break;
    default:
      console.log("Invalid iconType");
  }
  return `<i class="${iconClasses} ${iconType} ${classNames}"></i>`;
};

const getInlineIcon = (iconType, classNames = "") => {
  return `<span>${getIconName(iconType)} ${getIcon(
    iconType,
    classNames + " inline-icon"
  )}</span>`;
};

const getBlockIcon = (iconType, classNames = "") => {
  return `<div class="img-icon"> ${getIcon(
    iconType,
    classNames + " img-icon-robot"
  )} <h1>${getIconName(iconType)}</h1> </div>`;
};

const getRobotwLabel = (robotType, labelType) => {
  return `<div class="stack-img">${getIcon(
    robotType,
    "fa-3x stack-img-robot"
  )}<span class="fa-stack fa-2x stack-img-bubble"><i class="fa-solid fa-comment fa-stack-2x"></i>${getIcon(
    labelType,
    "fa-stack-1x"
  )}</span></div>`;
};

const getMolPath = (
  molImg,
  molNum,
  molDir = `/static/stimuli`,
  molExt = `svg`
) => {
  console.assert(["mol", "sal", "opp", "same"].includes(molImg));
  return `${molDir}/ax_${molImg}_${molNum}.${molExt}`;
};

const sampleOne = (arr, weights) => {
  return jsPsych.randomization.sampleWithoutReplacement(arr, 1, weights)[0];
};
